import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../services/auth.service';

@Component({
  selector: 'app-listereclamation',
  templateUrl: './listereclamation.component.html',
  styleUrls: ['./listereclamation.component.css']
})
export class ListereclamationComponent implements OnInit {
  reclamations:any
  tel:any
 
  constructor(private http: HttpClient,private router:Router,private authservice:AuthService,private route:Router){
    this.tel= this.authservice.getClientDataFromToken().telephone

  }
  ngOnInit(): void {
this.getAllReclamtions(this.tel)  }
FilterParDate(telephone:any)
{
 this.http.get(`http://localhost:3000/ReclamationsDay/${telephone}`).subscribe(
  
  (result: any) => {
    console.log(result);
    

    this.reclamations = result;
  console.log(this.reclamations)
  this.reclamations.forEach((reclamation: any) => {
    if (reclamation.document == null) {
      reclamation.document = "rien";
    }
    if (reclamation.repond == true) {
      reclamation.repond = "Repond";
      
    }
    else{
      reclamation.repond = "Non Repond";

    }
  });
  }

);

}
  getAllReclamtions(telephone:any)
  {
   this.http.get(`http://localhost:3000/ReclamationsByClient/${telephone}`).subscribe(
    
    (result: any) => {
      console.log(result);
      

      this.reclamations = result;
      
      this.reclamations.forEach((reclamation: any) => {
        if (reclamation.document == null) {
          reclamation.document = "rien";
        }
        if (reclamation.repond == true) {
          reclamation.repond = "Repond";
          
        }
        else{
          reclamation.repond = "Non Repond";
  
        }
      });
      
      console.log(this.reclamations);
    
    })
  }
  viewReponse(key:any)
  {
    this.route.navigate(['reponse/'+key])
  }
}
