import { HttpClient } from '@angular/common/http';
import { Component } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { RepondService } from '../services/repond.service';

@Component({
  selector: 'app-voirreclamation',
  templateUrl: './voirreclamation.component.html',
  styleUrls: ['./voirreclamation.component.css']
})
export class VoirreclamationComponent {
  reclamations:any
  keyParams:any
  constructor( private parms : ActivatedRoute,private http: HttpClient,private reponseapi:RepondService)
  {
    this.parms.params.subscribe(query=>{
      return this.keyParams=query['key']
    })
  }
ngOnInit(): void {
  this.getDonneesReclamation(this.keyParams)
}
getDonneesReclamation(codec:any)
{
  console.log(codec)
  
 this.http.get(`http://localhost:3000/GetReclamation/${codec}`).subscribe(
  
  (result: any) => {
    console.log(result);
    

    this.reclamations = result;
    this.reclamations.forEach((reclamation: any) => {
      if (reclamation.document == null) {
        reclamation.document = "rien";
      }
      if (reclamation.repond == true) {
        reclamation.repond = "Repond";
      }
      else{
        reclamation.repond = "Non Repond";

      }
    });
  console.log(this.reclamations)
  }

);


}


}

