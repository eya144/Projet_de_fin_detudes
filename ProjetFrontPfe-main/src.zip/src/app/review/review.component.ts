import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute, Route, Router } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AvisService } from '../services/avis.service';
import { AuthService } from '../services/auth.service';
import { HttpClient } from '@angular/common/http';


@Component({
  selector: 'app-review',
  templateUrl: './review.component.html',
  styleUrls: ['./review.component.css']
})

export class ReviewComponent implements OnInit  {
  

  keyParams: any
  successMessage: any;
  errorMessage: any;
  valParams: any;
  avis: any;

 telephone
 valaParams:any
 
    constructor( private avisservice:AvisService,private route:Router, private parms : ActivatedRoute ,private authservice:AuthService,private http:HttpClient) {
   
    this.telephone=this.authservice.getClientDataFromToken().telephone;
      this.parms.params.subscribe(query=>{
        return this.keyParams=query['key']
      })
     
  
    this.parms.params.subscribe(query=>{
      return this.valParams=query['val']
    })
    this.parms.params.subscribe(query=>{
      return this.valaParams=query['vala']
    })
    console.log("key",this.keyParams)
    console.log("val",this.valParams)

  
  }
  ngOnInit() {
  }
 

  addavis(f: any) {
    let data = f.value;
    if (data.commentaire !== "") {
      let rating = (document.querySelector('input[name="rating"]:checked') as HTMLInputElement)?.value || null;
      console.log("rating", rating);
      let etoile =0;
      if(rating!=null)
      {
        etoile=parseInt(rating);
      }
      console.log("etoile",etoile);
      this.avisservice.addavis(this.authservice.getClientDataFromToken().telephone,this.keyParams,data.commentaire,etoile).subscribe(
        (response: any) => {
          this.errorMessage = null;
          this.successMessage = "Added it successfully";
        },
        (error: any) => {
          this.successMessage = null;
          this.errorMessage = error.error;
        }
      );
    } else {
      this.successMessage = null;
      this.errorMessage = "Commentaire required";
    }
    console.log(data);
  }
  
 
  gotoallAvis(key:any)
  {
    this.route.navigate(['allAvisByService/'+key])
  }
 
}
