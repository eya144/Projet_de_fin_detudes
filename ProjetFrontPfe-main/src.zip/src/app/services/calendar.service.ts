import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CalendarService {
 

  
  constructor(private http: HttpClient) { }
  
 
async fetchDataFromServer(codes:any,codea:any)
{
  console.log(codes,codea)
  const usernam = codes+'.'+codea;
  const pass = 'expressexpress1+';
  const authString = `${usernam}:${pass}`;
  const authHeader = `Basic ${btoa(authString)}`;
  // Les options pour la requête HTTP POST
  const httpOptions = {
    headers: new HttpHeaders({
      'Authorization': authHeader
    })
  };
  let response: any;
  try {
     response = await this.http.get('/api/v2.0/me/CalendarView?startDateTime=2010-01-01T08:00:00Z&endDateTime=2050-01-01T23:59:59Z&$top=10000', httpOptions).toPromise();
    console.log('calendar');
  
    console.log(response);
    return response; // return only the 'value' property

    
  } catch (error) {
    console.log('Error occurred:', error);
    return null;
  }
}
async fetchDataFromServerClient()
{
  const usernam = 'user1';
  const pass = 'expressexpress1+';
  const authString = `${usernam}:${pass}`;
  const authHeader = `Basic ${btoa(authString)}`;
  // Les options pour la requête HTTP POST
  const httpOptions = {
    headers: new HttpHeaders({
      'Authorization': authHeader
    })
  };
  let response: any;
  try {
     response = await this.http.get('/api/v2.0/me/CalendarView?startDateTime=2010-01-01T08:00:00Z&endDateTime=2050-01-01T23:59:59Z&$top=10000', httpOptions).toPromise();
    console.log('calendar');
  
    console.log(response);
    return response; // return only the 'value' property

    
  } catch (error) {
    console.log('Error occurred:', error);
    return null;
  }
}
async addDataFromServer(codea:any,codes:any,data:any)
{
  const usernam = codea+'.'+codes;
  const pass = 'expressexpress1+';
  const authString = `${usernam}:${pass}`;
  const authHeader = `Basic ${btoa(authString)}`;
  // Les options pour la requête HTTP POST
  const httpOptions = {
    headers: new HttpHeaders({
      'Authorization': authHeader
    })
  };
  let response: any;
  try {
     response = await this.http.post('/api/v2.0/me/events', data,httpOptions).toPromise();
    console.log('calendar');
  
    console.log(response);
    return response; // return only the 'value' property

    
  } catch (error) {
    console.log('Error occurred:', error);
    return null;
  }
}

deleteDataFromServer(codea:any,codes:any,id: any) {
  const usernam = codea+'.'+codes;
  const pass = 'expressexpress1+';
  const authString = `${usernam}:${pass}`;
  const authHeader = `Basic ${btoa(authString)}`;
  // Les options pour la requête HTTP DELETE
  const httpOptions = {
    headers: new HttpHeaders({
      'Authorization': authHeader
    })
  };

  return this.http.delete(`/api/v2.0/me/events/${id}`, httpOptions);
}
 
  
}
