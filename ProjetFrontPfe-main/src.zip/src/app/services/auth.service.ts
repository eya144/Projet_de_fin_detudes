import { HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable, catchError, map, tap, throwError } from 'rxjs';


@Injectable({
  providedIn: 'root'
})
export class AuthService {
  private apiUrl = 'http://localhost:3000';

  constructor(private http: HttpClient) {
  }

  login(telephone: string, password: string) {
    return this.http.post<any>(`${this.apiUrl}/login`, { telephone, password })

  }
addSession(telephone:string)
{
  const body={
    telephone:telephone
  }
  return this.http.post<any>(`${this.apiUrl}/session`,body)

}
updateSession(telephone:any)
{
  const body={
    telephone:telephone
  }
return this.http.put<any>(`${this.apiUrl}/session/end`,body)
}
  forgetPassword(telephone: string, password: string)
  {
    return this.http.put<any>(`${this.apiUrl}/clientPassword/${telephone}`, { telephone, password })

  }
getClientDataFromToken()
{
  let token = localStorage.getItem('token');
if(token){
  let data=JSON.parse(window.atob(token.split('.')[1]))
  return data;
}
}

  logout() {
    localStorage.removeItem('token');
  }

  isLoggedIn() {
    let token = localStorage.getItem('token');
    if(token){
      return true;
    }
    else{
      return false;
    }
  }


  sendVerificationCode(email: string,telephone:any): Observable<any> {
    return this.http.post<any>(`${this.apiUrl}/send-verification-code`, { email ,telephone});
  }

  register(client:any) {
    return this.http.post<any>(`${this.apiUrl}/register`,client);
  }


  getClient(tel: any) {
    return this.http.get(`http://localhost:3000/client/${tel}`);
  }
  updateClient(data:any) {
    console.log(data)
    return this.http.put(`http://localhost:3000/client/${data.get('telephone')}`, data);
  }

  deleteCompte(tel: any) {
    return this.http.delete(`http://localhost:3000/client/${tel}`);

  }
}


