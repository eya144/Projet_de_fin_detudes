import { Component, OnInit } from '@angular/core';
import { CalendarService } from '../services/calendar.service';
import dayGridPlugin from '@fullcalendar/daygrid';
import timeGridPlugin from '@fullcalendar/timegrid';
import listPlugin from '@fullcalendar/list';
import interactionPlugin from '@fullcalendar/interaction';

import * as moment from 'moment';
import { ActivatedRoute, Params } from '@angular/router';
import { DatePipe } from '@angular/common';
import { AuthService } from '../services/auth.service';
import { timeInterval } from 'rxjs';
import { HttpClient } from '@angular/common/http';
@Component({
  selector: 'app-eyaagenda',
  templateUrl: './eyaagenda.component.html',
  styleUrls: ['./eyaagenda.component.css'],
  providers: [DatePipe], // add DatePipe to the providers array

})
export class EyaagendaComponent  implements OnInit {
  eventss: any;
  time:any;
  calendarOptions: any;
  keyParams: any;
  valParams: any;
  lastTime: any;
 
  dataevent= {
    "Subject":"",
    "Body": {
      "ContentType": "HTML",
      "Content": ""
    },
    
    "Start": {
        "DateTime": "",
        "TimeZone":"UTC"
    },
    "End": {
        "DateTime": "",
        "TimeZone":"UTC"

    },

    "Attendees": [
      {
        "EmailAddress": {
          "Address": "",
          "Name": ""
        },
        "Type": "Required"
      }
    ],
    "Organizer": {
      "EmailAddress": {
          "Name": "Utilisateur 1",
          "Address": "user1@ed.loc"
      }
  },
      "Location": {
        "DisplayName": ""
    },
    "ReminderMinutesBeforeStart":15,
    "BodyPreview":null
  }
  Messagesuccess: any;
  Messageerror: any;
  telephone:any
  email:any
  data:any
 
  codeParams:any
  constructor(private http:HttpClient,private apiService: CalendarService,private parms:ActivatedRoute,private datePipe:DatePipe,private authservice:AuthService) {
    this.parms.params.subscribe(query=>{
      return this.keyParams=query['key']
    })
    console.log(this.keyParams)
    this.parms.params.subscribe(query=>{
      return this.valParams=query['val']
    })
    this.parms.params.subscribe(query=>{
      return this.codeParams=query['vala']
    })
    this.telephone=this.authservice.getClientDataFromToken().telephone
    this.email=this.authservice.getClientDataFromToken().email


   }
  ngOnInit() {
    this.http.get(`http://localhost:3000/formcontenu`).subscribe(
    
    (result: any) => {
      console.log(result);
      
    
      this.data = result;
      this.data.image=`http://127.0.0.1:3000/getLogo/${this.data.image}`
    console.log(this.data)
    }
    
    );

    this.eventss = this.getData();
    console.log('events', this.eventss);
  
    this.calendarOptions = {
      plugins: [dayGridPlugin, timeGridPlugin, listPlugin, interactionPlugin],
      initialView: 'listWeek',
        initialDate: new Date(), // Set initial date to today

      headerToolbar: {
        start: 'prev,next today',
        center: 'title',
        end: 'dayGridMonth,timeGridWeek,timeGridDay,listWeek'
      },
      events: this.eventss,
      eventClick: (info: { event: { extendedProps: { data: boolean; }; start: moment.MomentInput; end: moment.MomentInput; }; }) => {
        if (info.event.extendedProps.data) {
          alert('This event is already reserved! from '+moment(info.event.start).format('HH:mm') +' to '+moment(info.event.end).format('HH:mm') );
        } 
      },
      eventDidMount: (info: { event: { extendedProps: { data: any; }; start: moment.MomentInput; end: moment.MomentInput; }; el: { style: { backgroundColor: string; }; innerHTML: string; }; }) => {
        if (info.event.extendedProps.data) {
          info.el.style.backgroundColor = '#FF0000';
          info.el.innerHTML = moment(info.event.start).format('HH:mm') + '/' + moment(info.event.end).format('HH:mm');

        } else {
          info.el.style.backgroundColor = '#00e600'; // set background color to green
        }
      },
    };
  }

  async getData() {
    const events = [];
    const data = await this.apiService.fetchDataFromServer(this.codeParams,this.keyParams);
    console.log(data.value);

    for (const event of data.value) {
      const start = moment.utc(event.Start.DateTime, 'YYYY-MM-DDTHH:mm:ss').format();
      const end = moment.utc(event.End.DateTime, 'YYYY-MM-DDTHH:mm:ss').format();
      
      const record = { start, end };
      
      events.push({
        start,
        end,
        data: true
      });
    }
    
    console.log("dater",events)
    this.eventss = events;
    console.log("events",this.eventss)


    return events;
  }

  addrdv(f:any)
{
console.log(f.value)
let data =f.value
console.log("apres"+data.time)
  let durationMs = data.duree * 60 * 1000; // convert duration from minutes to milliseconds
  data.time=new Date(data.time)
 // data.time.setHours(data.time.getHours() + 1);
  console.log("aven",data.time)
  data.time=data.time.toISOString();

  let timeMs = new Date(data.time).getTime(); // convert time to milliseconds

  let lastTimeMs = timeMs + durationMs;
  let lastTime = new Date(lastTimeMs);
  lastTime.setHours(lastTime.getHours() - 1);

  this.lastTime=lastTime.toISOString();

  this.lastTime = this.datePipe.transform(lastTime, 'yyyy-MM-ddTHH:mm'); 
console.log(this.lastTime)
this.dataevent.Start.DateTime=data.time;
this.dataevent.End.DateTime=this.lastTime;
this.dataevent.Subject=data.sujet;
this.dataevent.BodyPreview=this.keyParams;
this.dataevent.Attendees[0].EmailAddress.Address=this.email
this.dataevent.Attendees[0].EmailAddress.Name=this.authservice.getClientDataFromToken().telephone
this.dataevent.Location.DisplayName=this.valParams;
this.dataevent.ReminderMinutesBeforeStart=parseInt(data.duree)
let originalDateTime = this.dataevent.End.DateTime;
let utcDateTime = new Date(originalDateTime + 'Z');
let pstDateTime = new Date(utcDateTime.getTime() - 7 * 60 * 60 * 1000);
let pstDateTimeString = pstDateTime.toISOString().slice(0, 16);
console.log("hellonew date",pstDateTimeString); // Output: 2023-04-20T07:53
if(this.checkdate(this.eventss,data.time,this.lastTime))
{
  if(this.apiService.addDataFromServer(this.codeParams,this.keyParams,this.dataevent)!=null)
  {console.log("success")
  console.log("eventtest",this.dataevent)

this.Messagesuccess="added it successsfully";
this.Messageerror=null;
setTimeout(() => {
this.ngOnInit()}, 2000);
}
   
  


else{
  console.log("echec")

  this.Messageerror="failed to add !!";
  this.Messagesuccess=null;
}

}
else{
  this.Messagesuccess=null
  this.Messageerror="There is another rdv in the same date please check again !!"
}

}
  now = new Date();

  // Define the minimum and maximum times
  minTime = '08:00';
  maxTime = '17:00';

  // Define the minimum and maximum dates
  minDate = new Date(this.now.getFullYear(), this.now.getMonth(), this.now.getDate());
  maxDate = new Date(this.now.getFullYear(), this.now.getMonth() + 1, 0);

  // Calculate the minimum and maximum date-times
  minDateTime() {
    return `${this.dateToString(this.minDate)}T${this.minTime}`;
  }

  maxDateTime() {
    return `${this.dateToString(this.maxDate)}T${this.maxTime}`;
  }

  // Check if the date is disabled
  isDisabled() {
    const today = new Date();
    return today > this.maxDate;
  }

  // Helper method to convert a date to string
  dateToString(date: Date) {
    const year = date.getFullYear();
    const month = this.padNumber(date.getMonth() + 1);
    const day = this.padNumber(date.getDate());
    return `${year}-${month}-${day}`;
  }

  // Helper method to pad a number with leading zero
  padNumber(num: number) {
    return num.toString().padStart(2, '0');
  } 
  
   checkdate(rdvList: any[], specificStartTime: string, specificEndTime: string): boolean {
    let test = true;
  
    const formattedSpecificStartTime = moment(specificStartTime, 'YYYY-MM-DDTHH:mm');
    const formattedSpecificEndTime = moment(specificEndTime, 'YYYY-MM-DDTHH:mm');
  
    for (const rdv of rdvList) {
      const end = moment(rdv.end.slice(0, 16), 'YYYY-MM-DDTHH:mm');
      const start = moment(rdv.start.slice(0, 16), 'YYYY-MM-DDTHH:mm');
      
      console.log(rdv.end, " ", rdv.start.slice(0, 16), " ", specificEndTime, " ", specificStartTime);
  
      if ((start.isBefore(formattedSpecificEndTime) && end.isAfter(formattedSpecificStartTime)) ||
        (formattedSpecificStartTime.isBefore(end) && formattedSpecificEndTime.isAfter(start))) {
        console.log('Conflict!');
        test = false;
      }
      else if (start==formattedSpecificEndTime)  {
      console.log('Success!');
      test=true
    }
    else if ( end==formattedSpecificStartTime)  {
      test=true
      console.log('Success!');
    }
    
    }
  
    return test;
  }
  

 
}
