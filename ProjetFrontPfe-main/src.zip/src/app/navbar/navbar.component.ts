import { Component } from '@angular/core';
import { AuthService } from '../services/auth.service';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.css']
})
export class NavbarComponent {

  isLoggedIn: any
tel:any
nb_reponses:any
data:any
  constructor(private authService: AuthService,private router : Router,private http:HttpClient) { }

  ngOnInit() {
    this.http.get(`http://localhost:3000/formcontenu`).subscribe(
    
    (result: any) => {
      console.log(result);
      
    
      this.data = result;
      this.data.image=`http://127.0.0.1:3000/getLogo/${this.data.image}`
    console.log(this.data)
    }
    
    );
      this.isLoggedIn =this.authService.isLoggedIn()
console.log(this.authService.getClientDataFromToken().telephone)
 this.tel=this.authService.getClientDataFromToken().telephone
 console.log(this.tel)
 this.getnbReponsesNonLu(this.tel)

  }
  getnbReponsesNonLu(tel:any)
  {
   this.http.get(`http://localhost:3000/countunreadReponses/${tel}`).subscribe(
    
    (result: any) => {
      console.log(result);
      
  
      this.nb_reponses = result.count;
      
      
    
    })
  }
  onLogout() {
    this.updateSession(this.authService.getClientDataFromToken().telephone)
    this.authService.logout();
 
    this.isLoggedIn=false
    this.router.navigateByUrl('');
 

  }

  updateSession(tel:any)
  {
    this.authService.updateSession(tel).subscribe(
      (response: any) => {
        console.log(response);
  },
      (error: any) => {
  
        console.log(error.error);
  
      }
    );
  }


  
  
}
