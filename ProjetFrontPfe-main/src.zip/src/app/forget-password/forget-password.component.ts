import { Component } from '@angular/core';
import { ApiService } from '../services/api.service';
import { Router } from '@angular/router';
import { AuthService } from '../services/auth.service';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-forget-password',
  templateUrl: './forget-password.component.html',
  styleUrls: ['./forget-password.component.css']
})
export class ForgetPasswordComponent {
  form: any;
  inputFields: any;
  steps: any;
  currentTab: number = 0;
token:any
  successMessage:any;
  errorMessage:any;
 

 data:any

  constructor(private authservice: AuthService,private router : Router,private http:HttpClient) { }

  ngOnInit() {
    this.http.get(`http://localhost:3000/formcontenu`).subscribe(
    
    (result: any) => {
      console.log(result);
      
    
      this.data = result;
      this.data.image=`http://127.0.0.1:3000/getLogo/${this.data.image}`
    console.log(this.data)
    }
    
    );
    this.form = document.getElementById("regForm")!;
    this.inputFields = this.form.querySelectorAll("input");
    this.steps = this.form.querySelectorAll(".step");
    this.showTab(this.currentTab);



    



  }

  showTab(n: number) {
    const tabs = this.form.querySelectorAll(".tab");
    tabs.forEach((tab: any) => {
      tab.style.display = "none";
    });
    tabs[n].style.display = "block";

    this.steps.forEach((step: any, i: number) => {
      if (i <= n) {
        step.classList.add("active");
      } else {
        step.classList.remove("active");
      }
    });

  }


  validateForm() {
    const currentTabFields = this.form.querySelectorAll(".tab")[this.currentTab].querySelectorAll("input");
    let valid = true;
    currentTabFields.forEach((field: any) => {
      if (field.value === "") {
        field.classList.add("invalid");
        valid = false;
      }
    });

    if (valid) {
      currentTabFields.forEach((field: any) => {
        field.classList.remove("invalid");
      });
    }

    return valid;
  }


forgetPassword(f:any)
{
  if(this.validateForm())
  {
    let data = f.value;
    console.log(data);
    

    // Call the login() function and set the value of `test`
    if(data.password == data.confirmpassword) {
      this.authservice.forgetPassword(data.telephone, data.password).subscribe(
        (response: any) => {
          console.log(response);
          this.errorMessage = null;
          this.successMessage = "Successfully updated";
          setTimeout(() => {
            this.router.navigateByUrl('/login');
          }, 2000);
        },
        (error: any) => {
          console.log(error.error);
          this.errorMessage = error.error.err;
          this.successMessage = null;
          console.log(this.errorMessage);
        }
      );
    } else {
      this.successMessage = null;
      this.errorMessage = "Password and Confirm Password do not match";
      console.log(this.errorMessage);
    }
    
   


  }
  

}
  

}
