import { Component } from '@angular/core';
import { AuthService } from '../services/auth.service';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';

@Component({
  selector: 'app-modifierclient',
  templateUrl: './modifierclient.component.html',
  styleUrls: ['./modifierclient.component.css']
})
export class ModifierclientComponent {
  successMessage: any;
  errorMessage: any;
  currentUser: any;
 
  error: any;
data:any
latitude:any
longitude:any
  constructor(private http:HttpClient,private authservice:AuthService,private router:Router){
    if (navigator.geolocation) {
    
      navigator.geolocation.getCurrentPosition(
        (position) => {
          this.latitude = position.coords.latitude;
          this.longitude = position.coords.longitude;
          console.log("donnes", this.latitude, this.longitude);
        },
        (error) => {
          console.log(`Error occurred: ${error.message}`);
        },
        { enableHighAccuracy: true, timeout: 5000, maximumAge: 0 }
      );
   }}
  
  
  ngOnInit() {
    this.http.get(`http://localhost:3000/formcontenu`).subscribe(
    
    (result: any) => {
      console.log(result);
      
    
      this.data = result;
      this.data.image=`http://127.0.0.1:3000/getLogo/${this.data.image}`
    console.log(this.data)
    }
    
    );
    console.log(this.authservice.getClientDataFromToken())
    this.getClientdata(this.authservice.getClientDataFromToken().telephone)
  }
  getClientdata(id:any){
  this.authservice.getClient(id).subscribe(
      (response) => {
        this.currentUser = response;
        console.log(this.currentUser)
        this.currentUser.dateNaissance=this.formatDate(this.currentUser.dateNaissance)
        this.currentUser.photo=`http://127.0.0.1:3000/getImges/${this.currentUser.photo}`;

      },
      (error) => {
        this.error = error.message;
      }
    );  
  }
  formatDate(date: string) {
    return new Date(date).toISOString().substring(0, 10);
  }
   
image:any;
select(e:any)
{this.image=e.target.files[0]}

Update(f:any)
{
let data = f.value;
console.log(data)
const formData = new FormData();

// append the other fields to the form data object
formData.append('email', data.email);
formData.append('code', data.code);
formData.append('telephone', data.telephone);
formData.append('nom', data.nom);
formData.append('prenom', data.prenom);
formData.append('dateNaissance', data.dateNaissance);
formData.append('password', data.password);
formData.append('latitude', this.latitude);
formData.append('longtitude', this.longitude);
formData.append('ville', data.ville);
formData.append('image',this.image);
        
this.authservice.updateClient(formData) .subscribe(
  (response: any) => {
    console.log(response);
    this.successMessage = "Compte a été modifier avec Success";
    this.errorMessage = ""
    // Wait for 2 seconds and then reload the page
setTimeout(() => {
  this.router.navigateByUrl('/updateAccount');
}, 2000);

  },
  (error: any) => {
console.log(error.error);
    this.errorMessage = error.error;
    this.successMessage =""
    
  }
);
}
}
