import { Component } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { ReclamationService } from '../services/reclamation.service';
import { AgencesService } from '../services/agences.service';
import { AuthService } from '../services/auth.service';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-reclamation',
  templateUrl: './reclamation.component.html',
  styleUrls: ['./reclamation.component.css']
})
export class ReclamationComponent {

  keyParams: any
  successMessage: any;
  errorMessage: any;
  valParams: any;
  agences: any;
  telephone: any;
  file:any;
select(e:any)
{this.file=e.target.files[0]}
 
data:any
 
    constructor(private http:HttpClient,private reclamtionservice:ReclamationService ,private agenceservice:AgencesService,private authservice:AuthService) {
   
    this.agenceservice.getAllagence().subscribe(
      (response: any) => {
        console.log(response)
        this.agences=response;
        console.log(this.agences)
      },
      (error: any) => {
        this.agences=null;
      }
    );

    this.telephone=this.authservice.getClientDataFromToken().telephone;

  }
  ngOnInit() {
    this.http.get(`http://localhost:3000/formcontenu`).subscribe(
    
    (result: any) => {
      console.log(result);
      
    
      this.data = result;
      this.data.image=`http://127.0.0.1:3000/getLogo/${this.data.image}`
    console.log(this.data)
    }
    
    );
  }
 

addreclamation(f:any){
 
    let data = f.value;
    
    const formData = new FormData();

    // append the other fields to the form data object
    formData.append('objectif_Reclamation', data.objectif_Reclamation);
    formData.append('contenu_Reclamation', data.contenu_Reclamation);
   
    formData.append('document',this.file);
           
this.reclamtionservice.addreclamtion(this.authservice.getClientDataFromToken().telephone,data.id_agence,formData).subscribe(
  (response: any) => {
    this.errorMessage=null
    this.successMessage = "added it successfully"
  },
  (error: any) => {
    this.successMessage=null
    this.errorMessage = error.error;
  }
);

console.log(data)


  }

 

    // TODO: Submit the review data to the server


}

